"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { ChatMessage, type Message } from "@/components/chat-message"
import { Mic, MicOff, Loader2, AlertCircle, SendHorizonal } from "lucide-react"
import { useEsp32 } from "@/app/contexts/esp32-context"
import { v4 as uuidv4 } from "uuid"
import { useToast } from "@/components/ui/use-toast"
import { Textarea } from "@/components/ui/textarea"

// Extend the Window interface for SpeechRecognition
declare global {
  interface Window {
    SpeechRecognition: any
    webkitSpeechRecognition: any
  }
}

export default function VoiceChatPage() {
  const [messages, setMessages] = useState<Message[]>([])
  const [isListening, setIsListening] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [interimTranscript, setInterimTranscript] = useState("")
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const recognitionRef = useRef<any>(null)
  const { esp32Ip, sendEsp32Command, isConnected } = useEsp32()
  const { toast } = useToast()

  useEffect(() => {
    if (scrollAreaRef.current) {
      const viewport = scrollAreaRef.current.querySelector("div[data-radix-scroll-area-viewport]")
      if (viewport) {
        viewport.scrollTop = viewport.scrollHeight
      }
    }
  }, [messages])

  useEffect(() => {
    if (!esp32Ip) {
      setMessages((prev) => [
        ...prev,
        {
          id: uuidv4(),
          sender: "system",
          content: "ESP32 IP address is not set. Please configure it using the WiFi icon in the header.",
          type: "system_error",
          timestamp: new Date(),
        },
      ])
    } else if (!isConnected) {
      setMessages((prev) => [
        ...prev,
        {
          id: uuidv4(),
          sender: "system",
          content: `Attempting to connect to ESP32 at ${esp32Ip}... If this persists, check the connection.`,
          type: "system_info",
          timestamp: new Date(),
        },
      ])
    } else {
      setMessages((prev) => [
        ...prev,
        {
          id: uuidv4(),
          sender: "system",
          content: `Connected to ESP32 at ${esp32Ip}. Ready for voice commands!`,
          type: "system_info",
          timestamp: new Date(),
        },
      ])
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [esp32Ip, isConnected])

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      toast({
        title: "Browser Not Supported",
        description: "Speech recognition is not supported in your browser.",
        variant: "destructive",
      })
      return
    }

    recognitionRef.current = new SpeechRecognition()
    const recognition = recognitionRef.current
    recognition.continuous = true
    recognition.interimResults = true
    recognition.lang = "en-US"

    recognition.onresult = (event: any) => {
      let finalTranscript = ""
      let currentInterim = ""
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          finalTranscript += event.results[i][0].transcript
        } else {
          currentInterim += event.results[i][0].transcript
        }
      }
      setTranscript((prev) => prev + finalTranscript)
      setInterimTranscript(currentInterim)
    }

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error", event.error)
      toast({ title: "Speech Error", description: `Error: ${event.error}`, variant: "destructive" })
      setIsListening(false)
    }

    recognition.onend = () => {
      if (isListening) {
        // If it ended prematurely and we still want to listen
        recognition.start()
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const toggleListening = () => {
    if (!recognitionRef.current) return
    if (isListening) {
      recognitionRef.current.stop()
      setIsListening(false)
      if (transcript.trim() || interimTranscript.trim()) {
        // Automatically send if there's content when stopping
        handleSendTranscript(transcript + interimTranscript)
        setTranscript("")
        setInterimTranscript("")
      }
    } else {
      setTranscript("") // Clear previous transcript
      setInterimTranscript("")
      recognitionRef.current.start()
      setIsListening(true)
    }
  }

  const handleSendTranscript = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return

    const userMessage: Message = {
      id: uuidv4(),
      sender: "user",
      content: textToSend,
      timestamp: new Date(),
    }
    setMessages((prev) => [...prev, userMessage])
    setIsLoading(true)
    setTranscript("") // Clear the text area after sending
    setInterimTranscript("")

    if (!esp32Ip) {
      setMessages((prev) => [
        ...prev,
        {
          id: uuidv4(),
          sender: "system",
          content: "Cannot send command: ESP32 IP address not set.",
          type: "system_error",
          timestamp: new Date(),
        },
      ])
      setIsLoading(false)
      return
    }

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: textToSend }),
      })

      if (!res.ok) throw new Error(`API error: ${res.statusText}`)
      const data = await res.json()

      const botResponse: Message = {
        id: uuidv4(),
        sender: "bot",
        content: data.message || "Processing...",
        type: data.type || "conversation",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, botResponse])

      if (data.type === "action" && data.command) {
        const commandResult = await sendEsp32Command(data.command)
        const feedbackMessage: Message = {
          id: uuidv4(),
          sender: "bot",
          content: commandResult.message,
          type: "action_feedback",
          success: commandResult.success,
          timestamp: new Date(),
        }
        setMessages((prev) => [...prev, feedbackMessage])
        if (!commandResult.success) {
          toast({ title: "ESP32 Command Failed", description: commandResult.message, variant: "destructive" })
        } else {
          toast({ title: "ESP32 Command Success", description: commandResult.message })
        }
      }
    } catch (error) {
      console.error("Chat error:", error)
      const errorMessage: Message = {
        id: uuidv4(),
        sender: "bot",
        content: "Sorry, I encountered an error trying to process your request.",
        type: "error",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
      toast({
        title: "Chat Error",
        description: "Could not communicate with the AI assistant.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex flex-col h-[calc(100vh-10rem)] bg-card rounded-xl shadow-2xl overflow-hidden border border-border">
      <div className="p-4 border-b flex items-center space-x-2">
        <Mic className="h-6 w-6 text-primary" />
        <h2 className="text-xl font-semibold">AI Voice Control</h2>
      </div>
      {!esp32Ip && (
        <div className="p-4 bg-yellow-500/10 text-yellow-300 border-b border-yellow-500/30 flex items-center space-x-2">
          <AlertCircle className="h-5 w-5 text-yellow-400" />
          <span>ESP32 IP not set. Please configure it via the WiFi icon in the header to send commands.</span>
        </div>
      )}
      <ScrollArea className="flex-grow p-4 space-y-4" ref={scrollAreaRef}>
        {messages.map((msg) => (
          <ChatMessage key={msg.id} message={msg} />
        ))}
        {isLoading &&
          messages[messages.length - 1]?.sender !== "bot" && ( // Show thinking only if last message isn't already bot
            <div className="flex items-center space-x-2 p-3 rounded-lg bg-secondary text-secondary-foreground max-w-[85%] mr-auto">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <span className="text-sm">AI is processing...</span>
            </div>
          )}
      </ScrollArea>
      <div className="p-4 border-t bg-background space-y-3">
        <Textarea
          value={transcript + interimTranscript}
          onChange={(e) => setTranscript(e.target.value)}
          placeholder={
            isListening
              ? "Listening..."
              : esp32Ip
                ? "Speak or type your command..."
                : "Set ESP32 IP to enable voice commands..."
          }
          className="min-h-[80px] resize-none"
          disabled={isLoading || !esp32Ip}
        />
        <div className="flex justify-center items-center space-x-3">
          <Button
            onClick={toggleListening}
            disabled={isLoading || !esp32Ip}
            variant={isListening ? "destructive" : "default"}
            size="lg"
            className="rounded-full w-16 h-16"
          >
            {isListening ? <MicOff className="h-7 w-7" /> : <Mic className="h-7 w-7" />}
            <span className="sr-only">{isListening ? "Stop Listening" : "Start Listening"}</span>
          </Button>
          <Button
            onClick={() => handleSendTranscript(transcript + interimTranscript)}
            disabled={isLoading || !(transcript.trim() || interimTranscript.trim()) || !esp32Ip}
            size="lg"
            className="rounded-full w-16 h-16"
          >
            {isLoading ? <Loader2 className="h-7 w-7 animate-spin" /> : <SendHorizonal className="h-7 w-7" />}
            <span className="sr-only">Send Transcript</span>
          </Button>
        </div>
        {isListening && (
          <p className="text-center text-sm text-muted-foreground">
            Speak now... Click mic to stop and send, or send button.
          </p>
        )}
      </div>
    </div>
  )
}
