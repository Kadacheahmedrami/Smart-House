import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai"
import { type NextRequest, NextResponse } from "next/server"

const MODEL_NAME = "gemini-1.5-flash-latest"

export async function POST(req: NextRequest) {
  const apiKey = process.env.GOOGLE_GENERATIVE_AI_API_KEY

  if (!apiKey) {
    return NextResponse.json({ error: "API key not configured." }, { status: 500 })
  }

  const genAI = new GoogleGenerativeAI(apiKey)
  const model = genAI.getGenerativeModel({ model: MODEL_NAME })

  try {
    const { message: userInput } = await req.json()

    if (!userInput) {
      return NextResponse.json({ error: "User input is required." }, { status: 400 })
    }

    const prompt = `
      You are an AI assistant for a smart home system controlled by an ESP32.
      Your goal is to understand the user's command and translate it into a specific action for the ESP32, or respond conversationally if it's not a command.

      Available devices and actions (target names are case-sensitive as used in the ESP32 API):
      - Garage: "open", "close" (target: "garage")
      - Window: "open", "close" (target: "window")
      - Door: "open", "close" (target: "door")
      - Garage LED: "on", "off" (target: "garage_led")
      - Room 1 LED: "on", "off" (target: "room1_led")
      - Room 2 LED: "on", "off" (target: "room2_led")
      - Buzzer: "on", "off", "beep" (target: "buzzer")

      Response Format:
      - If the user's query is a command for one of the above actions, respond with a JSON object:
        {"type": "action", "command": {"action": "ACTION_NAME", "target": "TARGET_NAME"}}
        Example: User says "Turn on the garage light". You respond: {"type": "action", "command": {"action": "on", "target": "garage_led"}}

      - If the user's query is a general question, greeting, or something not related to a direct command, respond conversationally.
        In this case, respond with a JSON object:
        {"type": "conversation", "message": "Your conversational response here."}
        Example: User says "Hello". You respond: {"type": "conversation", "message": "Hello! How can I assist with your smart home today?"}

      - If the user's command is ambiguous or unclear, ask for clarification.
        Respond with a JSON object:
        {"type": "clarification", "message": "Your clarification question here."}
        Example: User says "Turn off the light". You respond: {"type": "clarification", "message": "Which light would you like to turn off? The garage, room 1, or room 2 light?"}

      - If the user's query is a command but for an unsupported action or device, inform them.
        Respond with a JSON object:
        {"type": "error", "message": "Sorry, I can't perform that action. I can control garage, window, door, specific LEDs, and the buzzer."}

      User query: "${userInput}"

      Your JSON response:
    `

    const generationConfig = {
      temperature: 0.7, // Adjust for creativity vs. precision
      topK: 1,
      topP: 1,
      maxOutputTokens: 2048,
      responseMimeType: "application/json", // Ensure Gemini tries to output JSON
    }

    const safetySettings = [
      { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
      { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
      { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
      { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE },
    ]

    const result = await model.generateContent({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig,
      safetySettings,
    })

    const responseText = result.response.text()

    try {
      const jsonResponse = JSON.parse(responseText)
      return NextResponse.json(jsonResponse)
    } catch (e) {
      console.error("Failed to parse Gemini response as JSON:", responseText, e)
      // Fallback if Gemini doesn't produce valid JSON, though responseMimeType should help
      return NextResponse.json({
        type: "conversation",
        message: "I had a little trouble understanding that. Could you try rephrasing?",
      })
    }
  } catch (error) {
    console.error("Error in /api/chat:", error)
    return NextResponse.json({ error: "Internal server error processing your request." }, { status: 500 })
  }
}
